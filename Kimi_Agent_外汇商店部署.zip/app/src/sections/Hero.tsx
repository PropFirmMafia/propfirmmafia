import { useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Target, Clock, Users } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const trustIndicators = [
  { icon: Users, label: '1000+', sublabel: 'Traders Funded' },
  { icon: Target, label: '96%', sublabel: 'Success Rate' },
  { icon: Clock, label: '24/7', sublabel: 'Expert Support' },
];

export function Hero() {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const subheadlineRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const trustRef = useRef<HTMLDivElement>(null);
  const shardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Initial entrance animations
      const tl = gsap.timeline({ defaults: { ease: 'expo.out' } });

      // Headline animation - word by word
      if (headlineRef.current) {
        const words = headlineRef.current.querySelectorAll('.word');
        tl.fromTo(
          words,
          { y: 40, opacity: 0, clipPath: 'circle(0% at 50% 50%)' },
          { y: 0, opacity: 1, clipPath: 'circle(100% at 50% 50%)', duration: 0.8, stagger: 0.15 },
          0.3
        );
      }

      // Subheadline fade in
      tl.fromTo(
        subheadlineRef.current,
        { y: 20, opacity: 0, filter: 'blur(10px)' },
        { y: 0, opacity: 1, filter: 'blur(0px)', duration: 0.6 },
        0.7
      );

      // CTA buttons 3D flip
      if (ctaRef.current) {
        const buttons = ctaRef.current.querySelectorAll('button');
        tl.fromTo(
          buttons,
          { rotateX: -90, opacity: 0 },
          { rotateX: 0, opacity: 1, duration: 0.5, stagger: 0.1, ease: 'elastic.out(1, 0.5)' },
          0.9
        );
      }

      // Trust indicators stagger
      if (trustRef.current) {
        const items = trustRef.current.querySelectorAll('.trust-item');
        tl.fromTo(
          items,
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.4, stagger: 0.12 },
          1.1
        );
      }

      // Floating shards explosion
      if (shardsRef.current) {
        const shards = shardsRef.current.querySelectorAll('.shard');
        tl.fromTo(
          shards,
          { scale: 0, opacity: 0 },
          {
            scale: 1,
            opacity: 1,
            duration: 1,
            stagger: 0.05,
            ease: 'elastic.out(1, 0.5)',
          },
          0.5
        );
      }

      // Scroll-triggered parallax
      ScrollTrigger.create({
        trigger: sectionRef.current,
        start: 'top top',
        end: 'bottom top',
        scrub: true,
        onUpdate: (self) => {
          const progress = self.progress;
          if (contentRef.current) {
            gsap.set(contentRef.current, {
              y: -progress * 50,
              opacity: 1 - progress * 0.8,
            });
          }
        },
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={sectionRef}
      className="relative min-h-screen flex items-center justify-center overflow-hidden bg-black"
    >
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src="/images/hero-bg.jpg"
          alt=""
          className="w-full h-full object-cover opacity-60"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black" />
      </div>

      {/* Floating Shards */}
      <div ref={shardsRef} className="absolute inset-0 z-5 pointer-events-none overflow-hidden">
        {[...Array(8)].map((_, i) => (
          <div
            key={i}
            className={`shard absolute w-${4 + (i % 4)} h-${4 + (i % 4)} border border-red-500/30 animate-float`}
            style={{
              left: `${10 + i * 12}%`,
              top: `${15 + (i % 3) * 25}%`,
              animationDelay: `${i * 0.5}s`,
              transform: `rotate(${i * 45}deg)`,
            }}
          />
        ))}
      </div>

      {/* Content */}
      <div
        ref={contentRef}
        className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-20"
      >
        {/* Headline */}
        <h1
          ref={headlineRef}
          className="font-display text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-bold text-white mb-6 leading-tight"
        >
          <span className="word inline-block">Dominate</span>{' '}
          <span className="word inline-block text-red-500">the</span>{' '}
          <span className="word inline-block">Markets</span>
        </h1>

        {/* Subheadline */}
        <p
          ref={subheadlineRef}
          className="text-lg sm:text-xl text-gray-300 max-w-2xl mx-auto mb-10 leading-relaxed"
        >
          Professional prop firm solutions for traders who demand excellence. Challenge passing,
          funded accounts, and elite account management.
        </p>

        {/* CTA Buttons */}
        <div ref={ctaRef} className="flex flex-col sm:flex-row gap-4 justify-center mb-16 perspective-1000">
          <Button
            onClick={() => scrollToSection('#pricing')}
            size="lg"
            className="bg-red-600 hover:bg-red-700 text-white px-8 py-6 text-lg font-semibold rounded-md transition-all duration-300 hover:shadow-glow-strong hover:scale-105"
          >
            Start Your Journey
          </Button>
          <Button
            onClick={() => scrollToSection('#services')}
            size="lg"
            variant="outline"
            className="border-gray-600 text-white hover:bg-white/10 px-8 py-6 text-lg font-semibold rounded-md transition-all duration-300"
          >
            View Services
          </Button>
        </div>

        {/* Trust Indicators */}
        <div ref={trustRef} className="flex flex-wrap justify-center gap-8 sm:gap-12">
          {trustIndicators.map((item, index) => (
            <div key={index} className="trust-item flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-red-500/20 flex items-center justify-center">
                <item.icon className="w-5 h-5 text-red-500" />
              </div>
              <div className="text-left">
                <div className="text-xl sm:text-2xl font-bold text-white">{item.label}</div>
                <div className="text-xs sm:text-sm text-gray-400">{item.sublabel}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom Gradient */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black to-transparent z-10" />
    </section>
  );
}
