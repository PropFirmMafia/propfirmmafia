import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Check, ExternalLink } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const pricingPlans = [
  {
    title: 'Challenge Passing',
    price: '$250',
    period: 'per challenge',
    description: 'Professional challenge passing service',
    features: [
      'Any prop firm challenge',
      'Phase 1 & 2 included',
      '5-15 days completion',
      '96% success rate',
      'Free retry if failed',
      '24/7 support',
    ],
    cta: 'Get Started',
    featured: false,
  },
  {
    title: 'Account Management',
    price: '30%',
    period: 'profit share',
    description: 'Hands-free account management',
    features: [
      'No upfront fees',
      '10-20% monthly returns',
      'Professional traders',
      'Daily reports',
      'Risk management',
      'Cancel anytime',
    ],
    cta: 'Start Earning',
    featured: true,
    badge: 'MOST POPULAR',
  },
  {
    title: 'Mafia Prop EA',
    price: '$1,200',
    period: 'one-time',
    description: 'Automated trading solution',
    features: [
      '5 licenses included',
      'Lifetime updates',
      'Prop firm optimized',
      '24/7 trading',
      'Discord support',
      'Setup assistance',
    ],
    cta: 'Buy Now',
    featured: false,
  },
];

export function Pricing() {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Header animation
      if (headerRef.current) {
        gsap.fromTo(
          headerRef.current.querySelectorAll('.animate-item'),
          { y: 30, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.6,
            stagger: 0.1,
            ease: 'expo.out',
            scrollTrigger: {
              trigger: headerRef.current,
              start: 'top 80%',
              toggleActions: 'play none none none',
            },
          }
        );
      }

      // Cards animation
      if (cardsRef.current) {
        const cards = cardsRef.current.querySelectorAll('.pricing-card');
        
        cards.forEach((card, i) => {
          const isFeatured = i === 1;
          gsap.fromTo(
            card,
            {
              rotateY: i === 0 ? 30 : i === 2 ? -30 : 0,
              x: i === 0 ? -50 : i === 2 ? 50 : 0,
              scale: isFeatured ? 0.8 : 0.9,
              opacity: 0,
            },
            {
              rotateY: 0,
              x: 0,
              scale: isFeatured ? 1.05 : 1,
              opacity: 1,
              duration: 0.8,
              delay: i === 1 ? 0.15 : 0,
              ease: isFeatured ? 'elastic.out(1, 0.5)' : 'expo.out',
              scrollTrigger: {
                trigger: cardsRef.current,
                start: 'top 75%',
                toggleActions: 'play none none none',
              },
            }
          );
        });
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const handleCTAClick = () => {
    window.open('https://t.me/PropFirmMafia', '_blank');
  };

  return (
    <section
      id="pricing"
      ref={sectionRef}
      className="relative py-24 sm:py-32 bg-black"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div ref={headerRef} className="text-center mb-16">
          <span className="animate-item inline-block text-red-500 text-sm font-semibold tracking-widest uppercase mb-4">
            Pricing
          </span>
          <h2 className="animate-item font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">
            Choose Your <span className="text-red-500">Path</span>
          </h2>
          <p className="animate-item text-lg text-gray-400 max-w-2xl mx-auto">
            Transparent pricing with no hidden fees
          </p>
        </div>

        {/* Pricing Cards */}
        <div
          ref={cardsRef}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8 perspective-2000 items-center"
        >
          {pricingPlans.map((plan, index) => (
            <div
              key={index}
              className={`pricing-card relative rounded-xl p-6 sm:p-8 transition-all duration-500 preserve-3d ${
                plan.featured
                  ? 'bg-gradient-to-br from-red-950/50 to-black border-2 border-red-500/50 shadow-glow-xl scale-105 z-10'
                  : 'bg-gradient-to-br from-[#0a0a0a] to-[#1a1a1a] border border-gray-800 hover:border-red-500/30'
              }`}
              style={{ transformStyle: 'preserve-3d' }}
            >
              {/* Featured Badge */}
              {plan.featured && plan.badge && (
                <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-red-600 text-white px-4 py-1 text-xs font-semibold animate-glow-pulse">
                  {plan.badge}
                </Badge>
              )}

              {/* Title */}
              <h3 className="font-display text-xl font-bold text-white mb-2">
                {plan.title}
              </h3>

              {/* Description */}
              <p className="text-gray-400 text-sm mb-6">{plan.description}</p>

              {/* Price */}
              <div className="mb-6">
                <span className="font-display text-4xl sm:text-5xl font-bold text-white">
                  {plan.price}
                </span>
                <span className="text-gray-400 text-sm ml-2">{plan.period}</span>
              </div>

              {/* Features */}
              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, fIndex) => (
                  <li key={fIndex} className="flex items-center gap-3 text-sm text-gray-300">
                    <div className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 ${
                      plan.featured ? 'bg-red-500/20' : 'bg-gray-800'
                    }`}>
                      <Check className={`w-3 h-3 ${plan.featured ? 'text-red-500' : 'text-gray-400'}`} />
                    </div>
                    {feature}
                  </li>
                ))}
              </ul>

              {/* CTA */}
              <Button
                onClick={handleCTAClick}
                className={`w-full py-6 font-semibold transition-all duration-300 group ${
                  plan.featured
                    ? 'bg-red-600 hover:bg-red-700 text-white hover:shadow-glow'
                    : 'bg-gray-800 hover:bg-gray-700 text-white'
                }`}
              >
                {plan.cta}
                <ExternalLink className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
