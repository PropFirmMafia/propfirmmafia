import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Star, Quote } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const testimonials = [
  {
    name: 'Alex M.',
    quote:
      'Prop Firm Mafia passed my FTMO challenge in just 8 days. Professional service, great communication, and they delivered exactly what they promised. Already on my second payout!',
    rating: 5,
    service: 'Challenge Passing',
    size: 'large',
  },
  {
    name: 'Sarah K.',
    quote:
      'The account management service is incredible. 15% returns in my first month with zero effort on my part.',
    rating: 5,
    service: 'Account Management',
    size: 'small',
  },
  {
    name: 'James T.',
    quote:
      'Mafia Prop EA passed my challenge while I was on vacation. Best investment I\'ve made.',
    rating: 5,
    service: 'Mafia Prop EA',
    size: 'small',
  },
  {
    name: 'Michael R.',
    quote:
      'I\'ve tried other passing services before and got burned. These guys are different - transparent, professional, and they actually care about your success. Funded 3 accounts with them so far.',
    rating: 5,
    service: 'Challenge Passing',
    size: 'large',
  },
  {
    name: 'David L.',
    quote:
      'The support team is amazing. They walked me through every step and answered all my questions within minutes.',
    rating: 5,
    service: 'General',
    size: 'medium',
  },
  {
    name: 'Emma W.',
    quote:
      'Finally a service that delivers on its promises. My challenge was passed in 12 days and I\'m now trading a $100K funded account.',
    rating: 5,
    service: 'Challenge Passing',
    size: 'medium',
  },
];

export function Testimonials() {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Header animation
      if (headerRef.current) {
        gsap.fromTo(
          headerRef.current.querySelectorAll('.animate-item'),
          { y: 30, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.6,
            stagger: 0.1,
            ease: 'expo.out',
            scrollTrigger: {
              trigger: headerRef.current,
              start: 'top 80%',
              toggleActions: 'play none none none',
            },
          }
        );
      }

      // Cards deal animation
      if (gridRef.current) {
        const cards = gridRef.current.querySelectorAll('.testimonial-card');
        cards.forEach((card, i) => {
          const rotation = [-2, 1, 2, -1, 0, 1][i] || 0;
          gsap.fromTo(
            card,
            {
              y: 100,
              opacity: 0,
              rotate: rotation - 10,
            },
            {
              y: 0,
              opacity: 1,
              rotate: rotation,
              duration: 0.7,
              delay: i * 0.1,
              ease: 'expo.out',
              scrollTrigger: {
                trigger: gridRef.current,
                start: 'top 75%',
                toggleActions: 'play none none none',
              },
            }
          );
        });
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative py-24 sm:py-32 bg-black"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div ref={headerRef} className="text-center mb-16">
          <span className="animate-item inline-block text-red-500 text-sm font-semibold tracking-widest uppercase mb-4">
            Testimonials
          </span>
          <h2 className="animate-item font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">
            What Traders <span className="text-red-500">Say</span>
          </h2>
        </div>

        {/* Testimonials Grid */}
        <div
          ref={gridRef}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 perspective-1500"
        >
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className={`testimonial-card group relative bg-gradient-to-br from-[#0a0a0a] to-[#1a1a1a] border border-gray-800 rounded-xl p-6 transition-all duration-500 hover:border-red-500/30 hover:shadow-glow hover:-translate-y-4 hover:rotate-0 hover:z-10 ${
                testimonial.size === 'large' ? 'md:row-span-1' : ''
              }`}
              style={{
                transform: `rotate(${[-2, 1, 2, -1, 0, 1][index] || 0}deg)`,
              }}
            >
              {/* Quote Icon */}
              <div className="absolute top-4 right-4 opacity-10 group-hover:opacity-20 transition-opacity">
                <Quote className="w-10 h-10 text-red-500" />
              </div>

              {/* Rating */}
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star
                    key={i}
                    className="w-4 h-4 text-red-500 fill-red-500"
                  />
                ))}
              </div>

              {/* Quote */}
              <p className="text-gray-300 leading-relaxed mb-6 text-sm sm:text-base">
                "{testimonial.quote}"
              </p>

              {/* Author */}
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-semibold text-white">{testimonial.name}</div>
                  <div className="text-xs text-gray-500">{testimonial.service}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
