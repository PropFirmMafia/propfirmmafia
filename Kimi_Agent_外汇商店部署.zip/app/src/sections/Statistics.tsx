import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useCountUp } from '@/hooks/useCountUp';
import { useInView } from '@/hooks/useInView';
import { Users, Target, Clock, Briefcase, DollarSign } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const stats = [
  { icon: Users, value: 1000, suffix: '+', label: 'Traders Funded' },
  { icon: Target, value: 96, suffix: '%', label: 'Success Rate' },
  { icon: Clock, value: 24, suffix: '/7', label: 'Expert Support' },
  { icon: Briefcase, value: 100, suffix: '+', label: 'Accounts Managed' },
  { icon: DollarSign, value: 2, suffix: 'M+', label: 'Profits Paid Out', prefix: '$' },
];

function StatItem({
  icon: Icon,
  value,
  suffix,
  label,
  prefix = '',
  delay,
  isInView,
}: {
  icon: typeof Users;
  value: number;
  suffix: string;
  label: string;
  prefix?: string;
  delay: number;
  isInView: boolean;
}) {
  const count = useCountUp({
    end: value,
    duration: 1500,
    delay: delay,
    enabled: isInView,
  });

  return (
    <div className="stat-item text-center p-6">
      <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-red-500/10 flex items-center justify-center">
        <Icon className="w-8 h-8 text-red-500" />
      </div>
      <div className="font-display text-4xl sm:text-5xl font-bold text-white mb-2">
        {prefix}
        {count}
        {suffix}
      </div>
      <div className="text-gray-400 text-sm">{label}</div>
    </div>
  );
}

export function Statistics() {
  const sectionRef = useRef<HTMLElement>(null);
  const { ref: containerRef, isInView } = useInView<HTMLDivElement>({ threshold: 0.3 });

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Background parallax
      gsap.to('.stats-bg', {
        y: -50,
        ease: 'none',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top bottom',
          end: 'bottom top',
          scrub: true,
        },
      });

      // Stat items entrance
      gsap.fromTo(
        '.stat-item',
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          stagger: 0.1,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: containerRef.current,
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative py-24 sm:py-32 bg-black overflow-hidden"
    >
      {/* Background Gradient */}
      <div className="stats-bg absolute inset-0 bg-gradient-to-b from-black via-red-950/10 to-black pointer-events-none" />

      {/* Decorative Lines */}
      <svg
        className="absolute inset-0 w-full h-full pointer-events-none opacity-20"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="transparent" />
            <stop offset="50%" stopColor="#ff0000" />
            <stop offset="100%" stopColor="transparent" />
          </linearGradient>
        </defs>
        <line
          x1="0"
          y1="50%"
          x2="100%"
          y2="50%"
          stroke="url(#lineGradient)"
          strokeWidth="1"
          strokeDasharray="8 8"
        />
      </svg>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div
          ref={containerRef}
          className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6 lg:gap-8"
        >
          {stats.map((stat, index) => (
            <StatItem
              key={index}
              icon={stat.icon}
              value={stat.value}
              suffix={stat.suffix}
              label={stat.label}
              prefix={stat.prefix}
              delay={200 + index * 100}
              isInView={isInView}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
