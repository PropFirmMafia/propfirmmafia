import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Target, Wallet, TrendingUp, Bot, Check } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const services = [
  {
    icon: Target,
    title: 'Challenge Passing',
    description:
      'Our expert traders pass your prop firm challenges with a 96% success rate. We handle Phase 1 & 2 while you relax.',
    price: 'From $250',
    features: [
      'Manual trading by pros',
      'Any prop firm supported',
      'Satisfaction guarantee',
      '5-15 days completion',
    ],
  },
  {
    icon: Wallet,
    title: 'Ready-Funded Accounts',
    description:
      'Skip the challenge entirely. Get instant access to funded accounts with major prop firms.',
    price: 'Contact Us',
    features: [
      'Instant funding',
      'No evaluation needed',
      'Multiple firms available',
      'Start trading today',
    ],
  },
  {
    icon: TrendingUp,
    title: 'Account Management',
    description:
      'Let our professional traders manage your funded account. Earn passive income while we handle the risk.',
    price: '30% Profit Share',
    features: [
      '10-20% monthly returns',
      'Professional risk management',
      'Daily performance reports',
      '100+ accounts managed',
    ],
  },
  {
    icon: Bot,
    title: 'Mafia Prop EA',
    description:
      'Our proprietary trading bot designed specifically for prop firm rules. Pass challenges on autopilot.',
    price: '$1,200',
    features: [
      '5 licenses included',
      'Prop firm optimized',
      '24/7 automated trading',
      'Regular updates',
    ],
  },
];

export function Services() {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Header animation
      if (headerRef.current) {
        gsap.fromTo(
          headerRef.current.querySelectorAll('.animate-item'),
          { y: 50, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.8,
            stagger: 0.15,
            ease: 'expo.out',
            scrollTrigger: {
              trigger: headerRef.current,
              start: 'top 80%',
              toggleActions: 'play none none none',
            },
          }
        );
      }

      // Cards animation - stacked to grid
      if (cardsRef.current) {
        const cards = cardsRef.current.querySelectorAll('.service-card');
        
        gsap.fromTo(
          cards,
          {
            y: 100,
            opacity: 0,
            rotateZ: (i) => (i % 2 === 0 ? -3 : 3),
          },
          {
            y: 0,
            opacity: 1,
            rotateZ: 0,
            duration: 0.7,
            stagger: 0.12,
            ease: 'expo.out',
            scrollTrigger: {
              trigger: cardsRef.current,
              start: 'top 75%',
              toggleActions: 'play none none none',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="services"
      ref={sectionRef}
      className="relative py-24 sm:py-32 bg-black"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div ref={headerRef} className="text-center mb-16">
          <span className="animate-item inline-block text-red-500 text-sm font-semibold tracking-widest uppercase mb-4">
            Our Services
          </span>
          <h2 className="animate-item font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">
            Elite Trading <span className="text-red-500">Solutions</span>
          </h2>
          <p className="animate-item text-lg text-gray-400 max-w-2xl mx-auto">
            Comprehensive prop firm services designed to accelerate your trading career
          </p>
        </div>

        {/* Service Cards */}
        <div
          ref={cardsRef}
          className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8 perspective-1500"
        >
          {services.map((service, index) => (
            <div
              key={index}
              className="service-card group relative bg-gradient-to-br from-[#0a0a0a] to-[#1a1a1a] border border-gray-800 rounded-xl p-6 sm:p-8 transition-all duration-500 hover:border-red-500/50 hover:shadow-glow preserve-3d"
              style={{ transformStyle: 'preserve-3d' }}
            >
              {/* Icon */}
              <div className="w-14 h-14 rounded-lg bg-red-500/10 flex items-center justify-center mb-6 group-hover:bg-red-500/20 transition-colors duration-300">
                <service.icon className="w-7 h-7 text-red-500 group-hover:rotate-12 transition-transform duration-300" />
              </div>

              {/* Title */}
              <h3 className="font-display text-2xl font-bold text-white mb-3">
                {service.title}
              </h3>

              {/* Description */}
              <p className="text-gray-400 mb-4 leading-relaxed">{service.description}</p>

              {/* Price */}
              <div className="text-red-500 font-semibold text-lg mb-6">{service.price}</div>

              {/* Features */}
              <ul className="space-y-2">
                {service.features.map((feature, fIndex) => (
                  <li key={fIndex} className="flex items-center gap-2 text-sm text-gray-300">
                    <Check className="w-4 h-4 text-red-500 flex-shrink-0" />
                    {feature}
                  </li>
                ))}
              </ul>

              {/* Hover Glow Effect */}
              <div className="absolute inset-0 rounded-xl bg-red-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
