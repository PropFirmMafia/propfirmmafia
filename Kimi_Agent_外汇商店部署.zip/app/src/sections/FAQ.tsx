import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

gsap.registerPlugin(ScrollTrigger);

const faqItems = [
  {
    question: 'How long does challenge passing take?',
    answer:
      'Most challenges are completed within 5-15 trading days depending on market conditions and the specific prop firm\'s requirements. We prioritize risk management over speed.',
  },
  {
    question: 'What prop firms do you work with?',
    answer:
      'We work with all major prop firms including FTMO, FundedNext, The5ers, Venus Funded, FXIFY, and many more. If you have a specific firm in mind, just ask!',
  },
  {
    question: 'Is my account safe with you?',
    answer:
      'Absolutely. We use secure credential handling, never share your information, and our traders follow strict risk management protocols. Your account security is our top priority.',
  },
  {
    question: 'What happens if you fail my challenge?',
    answer:
      'We offer a free retry guarantee. If we fail your challenge due to our trading (not rule violations on your end), we\'ll pass your next challenge attempt at no additional cost.',
  },
  {
    question: 'How does account management work?',
    answer:
      'You provide us with access to your funded account, and our professional traders manage it for you. You keep 70% of profits, we take 30%. You receive daily performance reports and can withdraw anytime.',
  },
  {
    question: 'Can I use the Mafia Prop EA on multiple accounts?',
    answer:
      'Yes! The $1,200 package includes 5 licenses, allowing you to run the EA on 5 different accounts simultaneously across different prop firms.',
  },
];

export function FAQ() {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const accordionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Header animation
      if (headerRef.current) {
        gsap.fromTo(
          headerRef.current.querySelectorAll('.animate-item'),
          { y: 30, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.6,
            stagger: 0.1,
            ease: 'expo.out',
            scrollTrigger: {
              trigger: headerRef.current,
              start: 'top 80%',
              toggleActions: 'play none none none',
            },
          }
        );
      }

      // Accordion items animation
      if (accordionRef.current) {
        const items = accordionRef.current.querySelectorAll('.faq-item');
        gsap.fromTo(
          items,
          { x: -50, opacity: 0 },
          {
            x: 0,
            opacity: 1,
            duration: 0.5,
            stagger: 0.1,
            ease: 'expo.out',
            scrollTrigger: {
              trigger: accordionRef.current,
              start: 'top 75%',
              toggleActions: 'play none none none',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="faq"
      ref={sectionRef}
      className="relative py-24 sm:py-32 bg-black"
    >
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div ref={headerRef} className="text-center mb-16">
          <span className="animate-item inline-block text-red-500 text-sm font-semibold tracking-widest uppercase mb-4">
            FAQ
          </span>
          <h2 className="animate-item font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">
            Common <span className="text-red-500">Questions</span>
          </h2>
        </div>

        {/* Accordion */}
        <div ref={accordionRef}>
          <Accordion type="single" collapsible className="space-y-4">
            {faqItems.map((item, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="faq-item border border-gray-800 rounded-lg bg-gradient-to-br from-[#0a0a0a] to-[#1a1a1a] px-6 data-[state=open]:border-red-500/30 data-[state=open]:shadow-glow transition-all duration-300"
              >
                <AccordionTrigger className="text-left text-white hover:text-red-500 py-5 text-base sm:text-lg font-semibold transition-colors duration-300 [&[data-state=open]>svg]:rotate-45">
                  {item.question}
                </AccordionTrigger>
                <AccordionContent className="text-gray-400 pb-5 leading-relaxed">
                  {item.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
}
