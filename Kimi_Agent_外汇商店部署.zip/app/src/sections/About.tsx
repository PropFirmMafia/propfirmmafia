import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Button } from '@/components/ui/button';
import { Check, ExternalLink } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const features = [
  '5+ years trading experience',
  'Proven risk management systems',
  'Dedicated support team',
  'Transparent pricing',
];

export function About() {
  const sectionRef = useRef<HTMLElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Image animation
      gsap.fromTo(
        imageRef.current,
        { x: -100, opacity: 0, rotateY: 15 },
        {
          x: 0,
          opacity: 1,
          rotateY: 0,
          duration: 0.8,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
            toggleActions: 'play none none none',
          },
        }
      );

      // Content animation
      if (contentRef.current) {
        const items = contentRef.current.querySelectorAll('.animate-item');
        gsap.fromTo(
          items,
          { y: 30, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.6,
            stagger: 0.1,
            ease: 'expo.out',
            scrollTrigger: {
              trigger: contentRef.current,
              start: 'top 75%',
              toggleActions: 'play none none none',
            },
          }
        );
      }

      // Parallax on scroll
      gsap.to(imageRef.current, {
        y: -30,
        ease: 'none',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top bottom',
          end: 'bottom top',
          scrub: true,
        },
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const handleJoinClick = () => {
    window.open('https://t.me/PropFirmMafia', '_blank');
  };

  return (
    <section
      id="about"
      ref={sectionRef}
      className="relative py-24 sm:py-32 bg-black"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Image */}
          <div
            ref={imageRef}
            className="relative perspective-1000"
          >
            <div className="relative rounded-xl overflow-hidden group">
              <img
                src="/images/about-image.jpg"
                alt="Professional traders collaborating"
                className="w-full h-auto object-cover transition-transform duration-500 group-hover:scale-105"
              />
              {/* Overlay gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
            </div>
            
            {/* Decorative element */}
            <div className="absolute -bottom-4 -right-4 w-24 h-24 border-2 border-red-500/30 rounded-xl -z-10" />
            <div className="absolute -top-4 -left-4 w-16 h-16 bg-red-500/10 rounded-xl -z-10" />
          </div>

          {/* Content */}
          <div ref={contentRef}>
            <span className="animate-item inline-block text-red-500 text-sm font-semibold tracking-widest uppercase mb-4">
              About Us
            </span>
            
            <h2 className="animate-item font-display text-4xl sm:text-5xl font-bold text-white mb-6">
              The Mafia <span className="text-red-500">Difference</span>
            </h2>
            
            <div className="space-y-4 text-gray-400 leading-relaxed">
              <p className="animate-item">
                Prop Firm Mafia was founded by a team of elite traders who saw a gap in the market
                for reliable, professional prop firm services. We've been in the trenches, failed
                challenges, learned the hard way, and developed systems that work.
              </p>
              
              <p className="animate-item">
                Our mission is simple: help traders succeed. Whether you're struggling to pass a
                challenge or want passive income from your funded account, we have the expertise
                to make it happen.
              </p>
            </div>

            {/* Features */}
            <ul className="mt-8 space-y-3">
              {features.map((feature, index) => (
                <li
                  key={index}
                  className="animate-item flex items-center gap-3 text-gray-300 group"
                >
                  <div className="w-5 h-5 rounded-full bg-red-500/20 flex items-center justify-center group-hover:bg-red-500/30 transition-colors">
                    <Check className="w-3 h-3 text-red-500" />
                  </div>
                  <span className="group-hover:translate-x-1 transition-transform duration-300">
                    {feature}
                  </span>
                </li>
              ))}
            </ul>

            {/* CTA */}
            <div className="animate-item mt-10">
              <Button
                onClick={handleJoinClick}
                size="lg"
                className="bg-red-600 hover:bg-red-700 text-white px-8 py-6 text-lg font-semibold rounded-md transition-all duration-300 hover:shadow-glow group"
              >
                Join Our Community
                <ExternalLink className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
