import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Button } from '@/components/ui/button';
import { ExternalLink, Zap } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export function CTASection() {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      if (contentRef.current) {
        const items = contentRef.current.querySelectorAll('.animate-item');
        gsap.fromTo(
          items,
          { y: 30, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.6,
            stagger: 0.15,
            ease: 'expo.out',
            scrollTrigger: {
              trigger: sectionRef.current,
              start: 'top 70%',
              toggleActions: 'play none none none',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const handleCTAClick = () => {
    window.open('https://t.me/PropFirmMafia', '_blank');
  };

  return (
    <section
      ref={sectionRef}
      className="relative py-24 sm:py-32 bg-black"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div
          ref={contentRef}
          className="relative rounded-2xl overflow-hidden"
          style={{
            clipPath: 'polygon(0 10%, 100% 0, 100% 90%, 0 100%)',
          }}
        >
          {/* Background */}
          <div className="absolute inset-0 bg-gradient-to-br from-[#1a1a1a] via-[#0a0a0a] to-[#1a1a1a] animate-gradient-shift" />
          
          {/* Red glow overlay */}
          <div className="absolute inset-0 bg-gradient-to-br from-red-950/20 via-transparent to-red-950/10" />
          
          {/* Decorative lines */}
          <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-red-500/50 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-red-500/50 to-transparent" />

          {/* Content */}
          <div className="relative py-16 sm:py-24 px-6 sm:px-12 text-center">
            <h2 className="animate-item font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">
              Ready to Get <span className="text-red-500">Funded?</span>
            </h2>
            
            <p className="animate-item text-lg sm:text-xl text-gray-400 max-w-2xl mx-auto mb-10">
              Join thousands of successful traders who chose the Mafia way.
            </p>

            <div className="animate-item">
              <Button
                onClick={handleCTAClick}
                size="lg"
                className="bg-red-600 hover:bg-red-700 text-white px-10 py-7 text-lg font-semibold rounded-md transition-all duration-300 hover:shadow-glow-strong hover:scale-105 group animate-glow-pulse"
              >
                <Zap className="w-5 h-5 mr-2" />
                Join the Mafia Today
                <ExternalLink className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
            </div>

            <p className="animate-item mt-8 text-sm text-gray-500">
              Average response time: Under 5 minutes
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
